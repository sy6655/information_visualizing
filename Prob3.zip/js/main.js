console.log("hello world!") // Check if script loads

d3.csv('data/chocolate_gdp.csv')
    .then(data => {

        /*
        -------------------------------------------
        YOUR CODE STARTS HERE

        TASK 1 - Data Preprocessing

        TO-DO-LIST
        1. Remove rows with missing values in 'gdp_per_capita' or 'chocolate_consumption'
        2. Convert those two columns to numbers
        -------------------------------------------
        */

        // Your preprocessing code here


        /*
        -------------------------------------------
        YOUR CODE ENDS HERE
        -------------------------------------------
        */

        drawScatter(data);

    })
    .catch(error => {
        console.error(error);
    });

function drawScatter(data) {
    const svg = d3.select('svg');
    const margin = { top: 50, right: 50, bottom: 50, left: 50 };
    const width = +svg.attr('width') - margin.left - margin.right;
    const height = +svg.attr('height') - margin.top - margin.bottom;

    const chart = svg.append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);

    const xScale = d3.scaleLinear().range([0, width]);
    const yScale = d3.scaleLinear().range([height, 0]);

    // Domain 설정
    xScale.domain(d3.extent(data, d => d.gdp_per_capita));
    yScale.domain(d3.extent(data, d => d.chocolate_consumption));

    chart.append('g')
        .attr('transform', `translate(0,${height})`)
        .call(d3.axisBottom(xScale));
    chart.append('g')
        .call(d3.axisLeft(yScale));

    chart.selectAll('circle')
        .data(data)
        .enter()
        .append('circle')
        .attr('cx', d => xScale(d.gdp_per_capita))
        .attr('cy', d => yScale(d.chocolate_consumption))
        .attr('r', 5)
        .attr('fill', 'chocolate')
        .attr('opacity', 0.7);

    /*
    -------------------------------------------
    YOUR CODE STARTS HERE

    TASK 2 - Add brushing interaction

    TO-DO-LIST
    1. Implement d3.brush() with full extent of chart
    2. When brush ends, log the list of country names within the selected region
    -------------------------------------------
    */

    // Your brushing code here

    /*
    -------------------------------------------
    YOUR CODE ENDS HERE
    -------------------------------------------
    */
}
